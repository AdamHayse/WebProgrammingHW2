package edu.ccsu;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;
import javax.annotation.Resource;
import javax.sql.DataSource;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Matthew
 */
@WebServlet(name = "VoteServlet", urlPatterns = {"/VoteServlet"})
public class VoteServlet extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    
        @Resource(name = "jdbc/HW2DB")
        DataSource dataSource;
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        try {
            String[] musictype = request.getParameterValues("musictype");
            if (musictype != null) {
                Connection connect = dataSource.getConnection();
                String sql = "SELECT * from VOTES";
                PreparedStatement select = connect.prepareStatement(sql);
                ResultSet rs = select.executeQuery();
                
                Set<String> musicGenreSet = new HashSet<String>(Arrays.asList(musictype));
                Integer currentVotes = (Integer) request.getSession().getAttribute("sessionVotes");
                Integer allVotes = (Integer) getServletContext().getAttribute("contextVotes");
                while (rs.next()) {
                    if (musicGenreSet.contains(rs.getString("MUSICTYPE"))) {
                        int voteCount = rs.getInt("NUMVOTES");
                        voteCount++;
                        if (currentVotes==null)
                            currentVotes = 1;
                        else
                            currentVotes = currentVotes + 1;
                        if (allVotes == null)
                            allVotes = 1;
                        else
                            allVotes = allVotes + 1;
                        sql = "UPDATE VOTES set NUMVOTES = ? where MUSICTYPE = ?";
                        PreparedStatement ps = connect.prepareStatement(sql);
                        ps.setInt(1, voteCount);
                        ps.setString(2, rs.getString("MUSICTYPE"));
                        ps.executeUpdate();
                        ps.close();
                    }
                }
                request.getSession().setAttribute("sessionVotes", currentVotes);
                getServletContext().setAttribute("contextVotes", allVotes);
                rs.close();
                select.close();
                connect.close();
            }
            request.getRequestDispatcher("ShowResultsServlet").forward(request, response);
        } catch (Exception e) {
            out.println("An error has been detected, therfore music types cannot be retrieved from the database at this time  " + e.getMessage());
        } finally {
            out.close();
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
